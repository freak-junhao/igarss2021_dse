🛠 Installation
===============

PyPI version:

.. code-block:: bash

    $ pip install -U segmentation-models-pytorch


Latest version from source:

.. code-block:: bash

    $ pip install -U git+https://github.com/qubvel/segmentation_models.pytorch